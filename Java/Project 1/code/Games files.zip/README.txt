THE WorldCities2024_v3.txt file in this Zip is what is required to run these files correctly please use the given file

the old file contained carracters that java could not handle this file does not contain these types of carracters 